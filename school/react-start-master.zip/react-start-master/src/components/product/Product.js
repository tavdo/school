import React from "react";

export const Product = () =>{
    return(
        <>
            Product
        </>
    )
}