import React from "react";

export const Home = () => {
  return(
    <>
      Home
    </>
  )
}