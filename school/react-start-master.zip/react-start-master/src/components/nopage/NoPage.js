import React from 'react'

export const NoPage = () => {
  return (
    <div>404 Page Not Found</div>
  )
}
