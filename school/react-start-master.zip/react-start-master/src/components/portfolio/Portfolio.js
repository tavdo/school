import React from "react";

export const Portfolio = () =>{
    return(
        <>
            Portfolio
        </>
    )
}