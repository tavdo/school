import React from 'react'

export const Footer = () => {
  return (
    <div style={{textAlign : "center",padding:"20px 0", backgroundColor : "#5caafd"}}>&copy; copyright By Me</div>
  )
}