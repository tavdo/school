const ForgetPasswordPage = () =>{
    return(
        <div>ForgetPasswordPage</div>
    )
}

export default ForgetPasswordPage;