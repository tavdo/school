const BlogLayout = ({ children }) => {
  return (
    <>
      <div>This is the main layout</div>
      <div>{children}</div>
    </>
  );
};

export default BlogLayout;
