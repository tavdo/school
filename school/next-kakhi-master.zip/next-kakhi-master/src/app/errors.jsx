"use client"
"use modules"
const Errors = () =>{
    return (
        <div>Error</div>
    )
}

export default Errors;