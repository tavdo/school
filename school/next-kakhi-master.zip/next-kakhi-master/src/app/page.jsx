

const Home = () =>{
  // throw new Error("Error in Home");
  return <div>HomePage</div>;
}

export default Home;